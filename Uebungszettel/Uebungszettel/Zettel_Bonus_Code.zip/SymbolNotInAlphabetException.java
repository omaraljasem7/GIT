package hausuebung.profi_dfa_2;

public class SymbolNotInAlphabetException extends Exception{
}
