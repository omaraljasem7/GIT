package hausuebung.profi_dfa_2;

public class StateDoesNotExistException extends Exception{
}
