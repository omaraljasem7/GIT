
public class Quiz {

	private int field = 10;
	
	public static int FIELD = 20;
	
	public Quiz(int field) {
		this.field = field;
	}
	
	public Quiz() {
		this(FIELD);
	}
	
	public String toString() {
		return "field = " + field;
	}
	
	public static void main(String[] args) {
		System.out.println(new Quiz());
	}
	
}
