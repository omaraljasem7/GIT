class Konto {
	
	private String kontoNr;
	private double kontoStand;
	private int kundenNr;
	
	public Konto(String kontoNr, int kundenNr) {
		this.kontoNr = kontoNr;
		this.kundenNr = kundenNr;
	}

	public Konto(String kontoNr, double kontoStand, int kundenNr) {
		this(kontoNr, kundenNr);
		this.kontoStand = kontoStand;
	}

	public void einzahlen(double betrag) {
		if (betrag > 0.0) {
			kontoStand += betrag;
		}
	}

	public double abheben(double wunschBetrag) {
		if (wunschBetrag < kontoStand) {
			kontoStand -= wunschBetrag;
			return wunschBetrag;			
		} else {
			double result = kontoStand;
			kontoStand = 0.0;
			return result;
		}
	}

	public double getKontoStand() {
		return kontoStand;
	}

	public String getKontoNr() {
		return kontoNr;
	}

	public int getKundenNr() {
		return kundenNr;
	}
	
	public String toString() {
		
		return "Kunde " + kundenNr +  " hat auf dem Konto " + kontoNr + " " + kontoStand + "€.";
				
	}
	
	public static void main(String[] args) {
		Konto konto = new Konto("12345", 999);
		System.out.println(konto);

		System.out.println(args.length);

		for (String arg : args) {
			System.out.println(arg);
		}

		int a = Integer.parseInt(args[0]);
		int b = Integer.parseInt(args[1]);

		System.out.println( a + " + " + b + " = " + (a+b));
	}
	
}
