import java.util.Iterator;
import java.util.List;

class FilterIterator<T> implements Iterator<T> {
    private final Predicate<T> condition;
    Iterator<T> it;	// Iterator, der über alle Element geht.
    T cur = null;	// Musician, der aktuell gefunden wurde.

    public FilterIterator(Iterator<T> in, Predicate<T> condition) {
        it = in;	           // Speichern des Iterators
        this.condition = condition;
        cur = computeNext();      // Nächstes Ergebnis berechnen
    }

    public FilterIterator(List<T> in, Predicate<T> condition) {
        it = in.iterator();	           // Speichern des Iterators
        this.condition = condition;
        cur = computeNext();      // Nächstes Ergebnis berechnen
    }

    private T computeNext() {
        while (it.hasNext()) {	                // Durchlauf bis zum nächsten Ergebnis
            T tmp = it.next();
            if (condition.test(tmp)) // Prüfen der Bedingung
                return tmp;                       // Treffer
        }
        return null;		                // Kein Ergebnis
    }

    public boolean hasNext() {
        return (cur != null);
    }

    public T next() {
        T tmp = cur;
        cur = computeNext();   // Nächstes Ergebnis berechnen
        return tmp;
    }
}
