public class NameFilter implements Predicate<Musician> {
	public boolean test( Musician p ) {
		// return p.getName().equals(searchedName); // geht nicht
		return false;
	}
}