public interface Predicate<T> {

    public boolean test(T value);

}
