import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.Stream;

public class MyComp implements Comparator<Integer> {

    public int compare(Integer a, Integer b) {
        if (a < b)
            return -1;
        else if (a == b)
            return 0;
        else// if (a > b)
            return 1;
    }

    public static void main(String[] args) {
        Integer x = 1;
        Integer y = 2;

        System.out.println("x > y" + (new MyComp().compare(x, y) > 0));

        Stream.of(1,2,3).sorted(new MyComp());
    }
}
