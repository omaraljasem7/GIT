package generics;

import java.util.Iterator;

/**
 * Ein Iterator, der alle Elemente in einer LinkedList liefert.
 * @param <E> Elementtyp der Liste
 */
public class MyListIterator<E> implements Iterator<E> {

    private ListElement<E> cursor;

    protected MyListIterator(ListElement<E> head) {
        this.cursor = head;
    }

    @Override
    public boolean hasNext() {
        return cursor != null;
    }

    @Override
    public E next() {
        E result = cursor.data;
        cursor = cursor.next;
        return result;
    }
}
