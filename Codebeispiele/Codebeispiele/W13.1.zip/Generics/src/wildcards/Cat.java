package wildcards;

public interface Cat {
	void miau();
}
