package wildcards;

class Accumulator<T extends Number> {
  	// Über T kann jetzt auf die Methoden der Klasse
    // Number zugriffen werden.

    double accVal = 0.0;

    public void acc(T v) {
        accVal += v.doubleValue();
    }

}
