package wildcards;

// Double | Integer
//
public class Oder<T extends Number> {

    void m(T arg) {
        }

}
