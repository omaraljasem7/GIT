package wildcards;

public class CatDog implements Cat, Dog {
    @Override
    public void miau() {
        System.out.println("meow");
    }

    @Override
    public void wuff() {
        System.out.println("ruff");
    }
}
