package wildcards;

public class AnimalSound {

    public static <T extends Dog & Cat> void catDog(T t) {
        t.miau();
        t.wuff();
    }

    public static void main(String[] args) {
        catDog(new CatDog());
    }
}
