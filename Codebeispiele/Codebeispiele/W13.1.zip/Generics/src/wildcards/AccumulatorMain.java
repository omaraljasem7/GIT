package wildcards;

public class AccumulatorMain {

    public static void main(String[] args) {
        Accumulator<Number> acc = new Accumulator<Number>();

        acc.acc(Integer.valueOf(1));
        acc.acc(Double.valueOf(1.0));
        //Accumulator<String> acc2; // geht nicht
    }
}
