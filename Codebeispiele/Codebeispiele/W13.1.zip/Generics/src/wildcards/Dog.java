package wildcards;

public interface Dog {
	void wuff();
}
