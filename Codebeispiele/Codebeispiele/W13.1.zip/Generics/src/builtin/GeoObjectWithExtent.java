package builtin;

public abstract class GeoObjectWithExtent {
	protected double x, y;

	/**
	 *
	 * @param a x-coordinate of the center point
	 * @param b y-coordinate of the center point
	 */
	GeoObjectWithExtent(double a, double b) {
		x = a; y = b;
	}
	public abstract Rectangle envelope();
	
	public abstract double area();

	public double coverage() {
		return area() / envelope().area();
	}
}
