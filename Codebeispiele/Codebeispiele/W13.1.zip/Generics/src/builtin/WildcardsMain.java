package builtin;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class WildcardsMain {

    public static void main(String[] args) {
        List<GeoObjectWithExtent> geos = new LinkedList<>();
        List<Rectangle> rects = new LinkedList<>();
        List<Circle> circles = new LinkedList<>();

        Iterator<GeoObjectWithExtent> it = geos.iterator();

        Circle c1 = new Circle(1, 2, 3);
        Circle c2 = new Circle(0, 0, 1);

        Rectangle r1 = new Rectangle(1, 4, 2, 2);
        Rectangle r2 = new Rectangle(3, 3, 3, 1);

        geos.add(c1);
        geos.add(c2);
        geos.add(r1);
        geos.add(r2);

//        rects.add(c1); // nicht erlaubt
//        rects.add(c2); // nicht erlaubt
        rects.add(r1);
        rects.add(r2);

        circles.add(c1);
        circles.add(c2);
        // circles.add(r1); // nicht erlaubt
        // circles.add(r2); // nicht erlaubt

        areaOverAll(geos);

        addCircle(geos);
        //addCircle(rects); // das darf man nicht.
        // Es würde sonst die Annahme verletzt werden, dass rects nur Rechtecke enthählt

        Rectangle result = rects.get(2);

        areaOverAll(rects);
        areaOverAll(circles);

        // getAllRadii(geos); // geht nicht
    }

    static double areaOverAll(List<? extends GeoObjectWithExtent> list) {
        double res = 0.0;
        for (GeoObjectWithExtent s: list) {
            res += s.area();
        }
        return res;
    }

    static double getAllRadii(LinkedList<Circle> circles){
        double res = 0;
        for (Circle  c: circles) {
            res += c.getRadius();
        }
        return res;
    }

    static void addCircle(List<GeoObjectWithExtent> circles){
        circles.add(new Circle(1, 1, 1));
    }

}
