package builtin;

import java.util.ArrayList;
import java.util.List;

public class WrapperMain {

    public static void main(String[] args) {
        List<Integer> lint = new ArrayList<>();


        lint.add(10);

        Integer res = lint.get(0);

        System.out.println(lint.get(0) + 10 + res);
    }
}
