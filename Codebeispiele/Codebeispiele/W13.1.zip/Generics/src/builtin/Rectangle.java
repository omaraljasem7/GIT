package builtin;

public class Rectangle extends GeoObjectWithExtent {
    private double x;
    private double y;
    private double width;
    private double height;

    public Rectangle(double x, double y, double width, double height) {
        super(x + width/2, y + height/2);
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    @Override
    public Rectangle envelope() {
        return this;
    }

    public double area() {
        return width * height;
    }
}
