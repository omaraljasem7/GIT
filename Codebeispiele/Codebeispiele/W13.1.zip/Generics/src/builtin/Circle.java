package builtin;

public class Circle extends GeoObjectWithExtent {
	private double radius;
	
	public Circle(double a, double b, double r) {
		super(a,b);
		radius = r;
	}
		@Override
	public Rectangle envelope() {
		return new Rectangle(x - radius, y - radius, 2 * radius, 2* radius);
	}

	@Override	public double area() {
		return Math.PI*radius*radius;
	}

	public double getRadius() {
		return radius;
	}
}
