import java.io.*;
import java.util.Arrays;

public class MainBytestreams {

    public static void main(String[] args) throws IOException {
        ByteArrayOutputStream byteOS = new ByteArrayOutputStream();
        OutputStream bufferedOS = new BufferedOutputStream(byteOS, 16);
        DataOutputStream dataOS = new DataOutputStream(bufferedOS);

        dataOS.writeInt(127);
        System.out.println(Arrays.toString(byteOS.toByteArray()));
        dataOS.writeInt(1);
        dataOS.writeInt(2);
        dataOS.writeInt(3);
        dataOS.writeInt(4);
        System.out.println(Arrays.toString(byteOS.toByteArray()));
        dataOS.flush();
        System.out.println(Arrays.toString(byteOS.toByteArray()));
        dataOS.writeInt(5);  // Achtung: das wird erst geschrieben, wenn der Puffer voll ist
        byteOS.write(6);
        dataOS.flush();
        System.out.println(Arrays.toString(byteOS.toByteArray()));
        dataOS.close();
    }

}
