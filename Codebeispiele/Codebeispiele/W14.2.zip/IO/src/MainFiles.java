import java.io.File;
import java.io.FileInputStream;

public class MainFiles {

    public static void main(String[] args) throws Exception {
        File file;

        file = new File("hello.txt");
        System.out.println("=== Demo File");
        System.out.println("file.getPath()         	: " + file.getPath());
        System.out.println("file.getCanonicalPath()	: " + file.getCanonicalPath());
        System.out.println("file.isDirectory()     	: " + file.isDirectory());
        System.out.println("file.length()          	: " + file.length());
        System.out.println("file.exists()          	: " + file.exists());

        File dir = new File(".");
        System.out.println("=== Current Directory");
        System.out.println("file.list().length     	: " + dir.listFiles().length);
        System.out.println("Content: ");
        for (File currentFile : dir.listFiles()) {
            System.out.println("  " + (currentFile.isDirectory() ? "d " : "f ")  + currentFile.getPath());
        }

        System.out.println("Current Directory recursive");
        printAll(dir, "");

    }

    public static void printAll(File f, String prefix) {
        System.out.println(prefix + f.getName());
        if (f.isDirectory()) {
            for (File current : f.listFiles()) {
                printAll(current, prefix + "   ");
            }
        }
    }

}
