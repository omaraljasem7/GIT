import java.io.*;
import java.util.Arrays;

public class MainCharstreams {

    public static void main(String[] args) throws IOException {
        CharArrayWriter charWriter = new CharArrayWriter();
        Writer bufferedWriter = new BufferedWriter(charWriter, 16);

        bufferedWriter.write(97);
        bufferedWriter.write('b'); // wird automatisch zu int konvertiert
        System.out.println(Arrays.toString(charWriter.toCharArray()));
        bufferedWriter.write("cde"); // Strings dürfen auch geschrieben werden
        System.out.println(Arrays.toString(charWriter.toCharArray()));
        bufferedWriter.flush();
        System.out.println(Arrays.toString(charWriter.toCharArray()));
        bufferedWriter.write('f'); // Achtung: das wird erst geschrieben, wenn der Puffer voll ist
        charWriter.write('g');
        bufferedWriter.flush();
        System.out.println(Arrays.toString(charWriter.toCharArray()));
        bufferedWriter.close();
    }

}
