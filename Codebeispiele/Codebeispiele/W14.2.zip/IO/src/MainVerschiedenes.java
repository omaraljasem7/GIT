import java.io.*;

public class MainVerschiedenes {

    public static void main(String[] args) throws IOException {
        File file = new File("hello.txt");
        InputStream fileIS = new FileInputStream(file);
        while(fileIS.available() > 0) {
            int v = fileIS.read();
            System.out.println(v);
        }

        Writer writer = new OutputStreamWriter(System.out);
        try {
            writer.write("Hello Output Stream!");
        }
        finally {
            // Wir schließen den writer in jedem Fall.
            // Egal, ob alles erfolgreich war oder ein Fehler (Exception) aufgetreten ist
            writer.close();
        }

        // (nur zur Information)
        // abkürzende Schreibweise "Try with resources"
        // schließt einen Stream, Writer, Reader, oder andere Ressourcen automatisch
        try(Writer writer2 = new OutputStreamWriter(System.out)) {
            writer.write("Hello Output Stream!");
        }
    }

}
