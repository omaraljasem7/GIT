package oop.vererbungkonstruktoren;

public class KTest {
   public static void main(String[] args) {
      OK k = new K();

      k.m();
//      K k2 = new K(10);
   }
}