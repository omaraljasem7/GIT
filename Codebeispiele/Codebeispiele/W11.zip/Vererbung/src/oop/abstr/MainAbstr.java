package oop.abstr;

public class MainAbstr {

    public static void main(String[] args) {
        GeoObjectWithExtent geo =
            new Circle(1.0, 2.0, 10.0);
    }
}
