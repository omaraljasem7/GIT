package oop.abstr;

public abstract class Abbstr2 {
}
