package oop.vererbung4;

class UK extends OK {
    public int a = 27;

    UK() {
    }
}
