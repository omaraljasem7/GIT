package oop.vererbung4;

class OK {
    public float a = 14.0f;

    OK() {
    }

    String getString() {
        return Float.toString(this.a);
    }
}
