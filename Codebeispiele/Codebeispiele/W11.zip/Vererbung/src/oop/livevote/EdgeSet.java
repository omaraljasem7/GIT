package oop.livevote;

class EdgeSet {
    public final String name = "EdgeSet";

    public String getName() {
        return name;
    }
}

class Trajectory extends EdgeSet {
    public final String name = "Trajectory";

    public String getName() {
        return name;
    }
}