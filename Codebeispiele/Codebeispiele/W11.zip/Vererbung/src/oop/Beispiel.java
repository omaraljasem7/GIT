package oop;

public class Beispiel {

    public static void main(String[] args) {
        Object o = null;
        o = new String("Hallo");
//        String p = o;
    }
}
