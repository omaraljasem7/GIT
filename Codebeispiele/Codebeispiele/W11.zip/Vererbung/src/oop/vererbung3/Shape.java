package oop.vererbung3;

public interface Shape {
}
