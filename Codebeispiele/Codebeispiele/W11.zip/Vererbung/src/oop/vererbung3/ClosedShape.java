package oop.vererbung3;

public interface ClosedShape {
}
