package enumswitch;

enum Season{
    WINTER, SPRING, SUMMER, FALL
};
