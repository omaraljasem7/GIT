package enumswitch;

public class MainEnum {

    public static void main(String[] args) {
        Ampel zustand = Ampel.Gelb;
        System.out.println(zustand.ordinal());
        System.out.println(zustand.name());

        Ampel zustand2 = Ampel.valueOf("Rot");
        System.out.println(zustand2.toString());

        System.out.println("Mögliche Zustande");
        for (Ampel zs:
             Ampel.values()) {
            System.out.println(zs);
        }
    }
}
