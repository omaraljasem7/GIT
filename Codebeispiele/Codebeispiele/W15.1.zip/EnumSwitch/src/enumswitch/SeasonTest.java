package enumswitch;

public class SeasonTest {

public static String getGermanName(Season season) {
  return switch (season) {
    case WINTER -> "Winter";
    case SPRING -> "Frühling";
    case SUMMER -> "Sommer";
    case FALL   -> "Herbst";
  };
}

public static void main(String[] args) {
	for(Season s : Season.values())
       System.out.println(s + " = " + getGermanName(s));

}
}