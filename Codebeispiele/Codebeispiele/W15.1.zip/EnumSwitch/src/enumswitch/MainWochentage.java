package enumswitch;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainWochentage {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Wochentag tag = Wochentag.valueOf(reader.readLine());

        System.out.println(tag);
//        if (tag == Wochentag.Mo || tag == Wochentag.Di || tag == Wochentag.Mi ) {
//            System.out.println("Werktag");
//        } else if (tag == Wochentag.Sa || tag == Wochentag.So) {
//                System.out.println("Wochenende");
//
//        }

        switch(tag) {
            case Mo:
            case Di:
            case Mi:
            case Do:
            case Fr:
                System.out.println("Werktag");
                break;
            default:
                System.out.println("Wochenende");
        }

        System.out.println("2. Versuch");
        switch(tag) {
            case Mo -> {
                System.out.println("Montag ist ein");
                System.out.println("Werktag");
            }
            case Di, Mi, Do, Fr ->
                System.out.println("Werktag");
            default ->
                System.out.println("Wochenende");
        }

    }
}
