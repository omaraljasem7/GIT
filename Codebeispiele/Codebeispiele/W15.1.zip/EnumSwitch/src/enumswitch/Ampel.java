package enumswitch;

public enum Ampel {

    Gruen(true), Rot(false), Gelb(true), RotGelb(true);

    private boolean darfFahren;

    Ampel(boolean darfFahren) {
        this.darfFahren = darfFahren;
    }
}
