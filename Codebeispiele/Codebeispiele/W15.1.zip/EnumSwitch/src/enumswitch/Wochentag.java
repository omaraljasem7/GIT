package enumswitch;

public enum Wochentag {

    Mo, Di, Mi, Do, Fr, Sa, So;

}
