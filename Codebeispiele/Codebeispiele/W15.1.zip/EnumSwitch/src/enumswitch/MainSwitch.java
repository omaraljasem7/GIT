package enumswitch;

public class MainSwitch {

    public static void main(String[] args) {
        Wochentag w = Wochentag.Mo;
        int tageBisWochenende;
        String stimmung;

        switch(w) {
            case Mo -> {
                tageBisWochenende = 5;
                stimmung = "--";
            }
            case Di -> {
                tageBisWochenende = 4;
                stimmung = "-";
            }
            case Mi -> {
                tageBisWochenende = 3;
                stimmung = "0";
            }
            case Do -> {
                tageBisWochenende = 2;
                stimmung = "0";
            }
            case Fr -> {
                tageBisWochenende = 1;
                stimmung = "+";
            }
            case Sa, So -> {
                tageBisWochenende = 0;
                stimmung = "++";
            }

        }
    }

    static int getMonatAlsZahl(String monat) {
        int monatAlsZahl = 0;
        if (monat == null) return monatAlsZahl;
        switch (monat.toLowerCase()) {
            case "januar" ->     monatAlsZahl =  1;
            case "februar" ->    monatAlsZahl =  2;
            case "märz" ->       monatAlsZahl =  3;
            case "april" ->      monatAlsZahl =  4;
            case "mai" ->        monatAlsZahl =  5;
            case "juni" ->       monatAlsZahl =  6;
            case "juli" ->       monatAlsZahl =  7;
            case "august" ->     monatAlsZahl =  8;
            case "september" ->  monatAlsZahl =  9;
            case "oktober" ->    monatAlsZahl = 10;
            case "November" ->   monatAlsZahl = 11;
            case "dezember" ->   monatAlsZahl = 12;
            default ->           monatAlsZahl =  0;
        }
        return monatAlsZahl;
    }

    static int getMonatAlsZahl2(String monat) {
        if (monat == null) return 0;
        return switch (monat.toLowerCase()) {
            case "januar" ->       1;
            case "februar" ->      2;
            case "märz" ->         3;
            case "april" ->        4;
            case "mai" ->          5;
            case "juni" ->         6;
            case "juli" ->         7;
            case "august" ->       8;
            case "september" ->    9;
            case "oktober" ->     10;
            case "November" ->    11;
            case "dezember" ->    12;
            default ->             0;
        }; // ACHTUNG: hier wird ein Semikolon benötigt, weil die
        // return-Anweisung noch abgeschlossen werden muss.
    }
}
