import java.security.spec.NamedParameterSpec;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;

public class Main {

    public static void main(String[] args) {
        List<Musician> musicians = new ArrayList<>();

        musicians.add(new Musician("Wilson"));
        musicians.add(new Musician("Jim"));

        Iterator<Musician> it = new FilterIterator<>(musicians, new WilsonFilter());
        while(it.hasNext()) {
            System.out.println(it.next());
        }

        Iterator<Musician> it2 = new FilterIterator<Musician>(
                musicians,
                x -> {return x.getName().equals("Wilson");});
        while(it2.hasNext()) {
            System.out.println(it2.next());
        }

        musicians.forEach(p -> {
            if (p.getName().equals("Wilson"))
                System.out.println(p);
        } );


        // Äquivalent

        for (Musician p : musicians) {
            if (p.getName().equals("Wilson"))
                System.out.println(p);
        }

        Consumer<Musician> cons = p -> System.out.println(p);

        musicians.forEach(cons);

        String searchedName = "Wilson";

        System.out.println(searchedName + "!");
        Iterator<Musician> it3 = new FilterIterator<Musician>(
                musicians,
                x -> x.getName().equals(searchedName));
        while(it3.hasNext()) {
            System.out.println(it3.next());
        }



    }

}
