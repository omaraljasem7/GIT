import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MusicianPrinter {

	private static List<MusicianPrinter> printers = new ArrayList<>();

	private Musician theMusician;

	public MusicianPrinter(Musician musician) {
		this.theMusician = musician;
		printers.add(this);
	}

	public void print() {
		System.out.println("Printer with MusicianPrinter: " + theMusician.getName());
	}


	public static void main(String[] args) {
		List<Musician> musicians = Arrays.asList(
				new Musician("Wilson"),
				new Musician("Jim"));
		musicians.forEach( x -> System.out.println(x) );

		PrintStream ps = System.out;
		musicians.forEach( ps::println );

		musicians.forEach( MusicianPrinter::printMusician );
		System.out.println("for each constructor {");
		musicians.forEach( MusicianPrinter::new );
//		musicians.forEach( x -> new MusicianPrinter(x) );
		System.out.println("for each constructor }");
		printers.forEach( MusicianPrinter::print );
		//musicians.stream().filter(m -> m.getName().equals("Wilson")).forEach(System.out::println);
	}

	public static void printMusician(Musician m) {
		System.out.println("Musician: " + m.getName());
	}
}
