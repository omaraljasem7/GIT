public class WilsonFilter implements Predicate<Musician> {
	public boolean test( Musician p ) {
		return p.getName().equals("Wilson");
	}
}