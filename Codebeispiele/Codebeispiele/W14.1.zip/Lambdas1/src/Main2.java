import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Main2 {

    public static void main(String[] args) {
        Stream<List<Integer>> ls = Stream.of(
                Arrays.asList( 1, 3, 5, 7 ),
                Arrays.asList( 2, 4, 6, 7 ) );
        ls.flatMap(l -> l.stream() ).forEach(System.out::println);

    }
}
