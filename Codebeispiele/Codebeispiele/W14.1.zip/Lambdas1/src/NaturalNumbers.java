import java.util.Random;
import java.util.function.Supplier;
import java.util.stream.Stream;

class NaturalNumbers implements Supplier<Integer> {
    Integer next = 1;

    @Override
    public Integer get() {
        return next++;
    }

    public static void main(String[] args) {
        Stream<Integer> s = Stream.generate(new NaturalNumbers());
        System.out.println("Ich bin fertig.");
//        s.forEach(System.out::println); // terminiert nicht

        Stream.generate(new NaturalNumbers()).limit(10)
                .forEach(System.out::println);
    }
}
