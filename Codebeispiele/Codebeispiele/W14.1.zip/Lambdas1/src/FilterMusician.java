import java.util.Iterator;
import java.util.List;

class FilterMusician implements Iterator<Musician> {

    Iterator<Musician> it;	// Iterator, der über alle Element geht.
    Musician cur = null;	// Musician, der aktuell gefunden wurde.

    public FilterMusician(Iterator<Musician> in) {
        it = in;	           // Speichern des Iterators
        cur = computeNext();      // Nächstes Ergebnis berechnen
    }

    public FilterMusician(Iterable<Musician> in) {
        it = in.iterator();	           // Speichern des Iterators
        cur = computeNext();      // Nächstes Ergebnis berechnen
    }

    private Musician computeNext() {
        while (it.hasNext()) {	                // Durchlauf bis zum nächsten Ergebnis
            Musician tmp = it.next();
            if (tmp.getName().equals("Wilson")) // Prüfen der Bedingung
                return tmp;                       // Treffer
        }
        return null;		                // Kein Ergebnis
    }

    public boolean hasNext() {
        return (cur != null);
    }

    public Musician next() {
        Musician tmp = cur;
        cur = computeNext();   // Nächstes Ergebnis berechnen
        return tmp;
    }
}
