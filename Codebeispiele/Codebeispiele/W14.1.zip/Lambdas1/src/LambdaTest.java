import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class LambdaTest {

    public static void main(String[] args) {
        List<Integer> values = Arrays.asList(42,33,7,88,23);
        values.forEach(x -> System.out.println(x));
    }
}