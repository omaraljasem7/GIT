public class Musician {

    private String s;
    public Musician(String s)
    {
        this.s = s;
    }
    String getName() {
        return s;
    }
}
