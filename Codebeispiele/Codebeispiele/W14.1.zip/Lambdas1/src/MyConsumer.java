import java.util.function.Consumer;

public class MyConsumer implements Consumer<Musician> {

    public void accept(Musician m) {
        System.out.println(m);
    }
}
