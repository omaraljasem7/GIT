import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.BaseStream;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class MainStreams {

    public static void main(String[] args) {
        List<Integer> li = new LinkedList<>();
        li.add(1);
        li.add(2);
        li.add(3);
        li.add(4);
        Stream<Integer> s1 = li.stream();

        Stream<Integer> s2 = Stream.of(1, 2, 3, 4, 5, 6, 7, 8);

//        Random rand = new Random(System.currentTimeMillis());
//        Stream<Integer> s3 = Stream.generate(rand::nextInt);
//        s3.limit(10).forEach(System.out::println);

        Stream<Integer> s4_urspruenglich = Stream.of(1,2,3,4);
        Stream<Integer> s4 = s4_urspruenglich
                .filter( x -> x % 2 == 0 );
        s4.forEach(System.out::println);

        Stream<String> s5 = Stream.of(3,2,4,1)
         .map( x -> Integer.toString(x) + "x" );

        s5.forEach(System.out::println);


        Stream<List<Integer>> ls = Stream.of(
                Arrays.asList( 1, 3, 5, 7 ),
                Arrays.asList( 2, 4, 6, 8 ) );
        Stream<Integer> s6 = ls.flatMap( l -> l.stream() );
        s6.forEach(System.out::println);

//        Stream<List<Number>> ls = Stream.of(
//                Arrays.asList( 1, 3, 5, 7 ),
//                Arrays.asList( 2.0, 4.0, 6.0, 8.0 ) );
//        Stream<Number> s6 = ls.flatMap( l -> l.stream() );
//        s6.forEach(System.out::println);

//
//        Stream<Integer> s = Stream.of(3,2,4,1)
//                .sorted((a, b) -> a.compareTo(b) * -1);
//
//        Stream.of(5,4,7,2,10,8)
//                .filter( x -> {
//                    System.out.println("Filter: " + x);
//                    return x % 2 == 0;
//                });
//
//        Stream.of(5,4,7,2,10,8)
//                .sorted( (x,y) -> {
//                    System.out.println("Sort: " + x + ";" + y);
//                    return x.compareTo(y);} )
//                .filter( x -> {
//                    System.out.println("Filter: " + x);
//                    return x % 2 == 0; } )
//                .forEach(
//                        x -> System.out.println("ForEach: " + x)
//	);


        //s1.collect(Collectors.toList());

        List<Character> loc = Arrays.asList('a', 'b', 'c');

        loc.stream().map(c -> (int) c).forEach(System.out::println);

        IntStream soc = "abc".chars();
        soc.map(c -> (int) c).forEach(System.out::println);
    }
}
