import java.util.function.BiFunction;
import java.util.function.Function;

public class MainLambdas {

    // Parametertypen: String[]
    // Rückgabetyp: void
    public static void main(String[] args) {
        // Parametertypen: int, int
        // Rückgabetyp: int
        MyBinOperation myLambda = (a, b) -> a + b;
        BiFunction<Integer, Integer, Integer> myLambda2 = (Integer a, Integer b) -> a.intValue() + b.intValue();

    }


    // Parametertypen: int, int
    // Rückgabetyp: int
    public static int add(int a, int b) {
        return a + b;
    }

}
