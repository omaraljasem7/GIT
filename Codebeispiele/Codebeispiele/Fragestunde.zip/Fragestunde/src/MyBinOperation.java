import java.util.function.BiFunction;

public interface MyBinOperation {

    int op(int a, int b);

}
