import java.io.*;
import java.util.Random;

public class MainExceptions {

    public static void main(String[] args) {
        BufferedReader keyboardReader = new BufferedReader(new InputStreamReader(System.in));
        boolean busy = true;
//        while(busy) {
            String fname = null;
            try {
                fname = keyboardReader.readLine();
            } catch (IOException e) {
                // ignore
            }
            try {
                store(fname);
//                busy = false;
                main(args);


            } catch (FileNotFoundException e) {
                System.out.println("Der Dateiname ist ungültig bitte neuen eingeben.");

           } catch (IOException e) {
            System.out.println("Konnte nicht schreiben");
            return;
            } catch (Exception e) {
                System.out.println("Anwendeungsfehler");
                return;
            }
//        }
        System.out.println("Fertig");
    }

    public static void store(String fname) throws IOException {
        FileOutputStream fout = new FileOutputStream(fname);
        int i = 10;
        int j = new Random().nextInt(5);
        fout.write(i / j);
        fout.close();
    }
}
