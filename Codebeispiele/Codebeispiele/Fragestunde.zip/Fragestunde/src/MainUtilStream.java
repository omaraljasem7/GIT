import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class MainUtilStream {

    public static void main(String[] args) {
        Stream<Stream<Integer>> ls = Stream.of(
                Arrays.asList( 1, 3, 5, 7 ).stream(),
                Arrays.asList( 2, 4, 6, 8 ).stream() );
        Stream<Integer> s = ls.flatMap( l -> l );
        s.forEach(System.out::println);
    }
}
