import java.util.Arrays;
import java.util.List;

public class MainWildcards {

    // Object
    //  /\
    //  |
    // Number
    //  /\
    //  |
    // Integer

    public static void main(String[] args) {
        List<Number> lNum = Arrays.asList(1, 2);
        doSomething1(lNum);
        doSomething2(lNum);
        doSomething3(lNum);

        List<Integer> lInt = Arrays.asList(1, 2);
        doSomething1(lInt);
        doSomething2(lInt);
//        doSomething3(lInt); // darf ich nicht!
        Integer i = lInt.get(2);

        List<Object> lObj = Arrays.asList(1, 2);
        doSomething1(lObj);
        lObj.add("Str");
//        doSomething2(lObj); // darf ich nicht!
        doSomething3(lObj);

    }

    public static void doSomething1(List<?> l) {
        System.out.println(l.size());
    }

    // ? extends XXX
    // ich darf auf Methoden zugreifen die den Typparameter im Rückgabetyp haben
    // und der Rückgabewert darf einer Variablen vom Typ XXX zugewiesen werden
    public static void doSomething2(List<? extends Number> l) {
        Number n = l.get(0);
    }
    // ? super XXX
    // ich darf auf Methoden zugreifen, die den Typparameter in der
    // Paramaterliste verwendet und darf dann jeden Wert vom Typ XXX übergeben
    public static void doSomething3(List<? super Number> l) {
        l.add((Number) Double.valueOf(1.0));
    }


}
