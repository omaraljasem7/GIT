public class ImplicitExceptions {

    public static void main(String[] args) {
        int i = Integer.parseInt(args[0]);
        System.out.println("Meine Zahl: " + (i + 1));
    }
}
