package edges;

public class EdgeException extends Exception {

    public EdgeException(String message) {
        super(message);
    }

}
